package com.nikai.sportsapp;

public class Match {
    private String title;
    private String streamUrl;

    public Match(String title, String streamUrl) {
        this.title = title;
        this.streamUrl = streamUrl;
    }

    public String getTitle() { return title; }
    public String getStreamUrl() { return streamUrl; }
}
