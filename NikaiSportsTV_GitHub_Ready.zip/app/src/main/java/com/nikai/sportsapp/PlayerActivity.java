package com.nikai.sportsapp;

import android.net.Uri;
import android.os.Bundle;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

public class PlayerActivity extends AppCompatActivity {

    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        videoView = findViewById(R.id.videoView);
        String streamUrl = getIntent().getStringExtra("stream_url");

        if (streamUrl != null) {
            videoView.setVideoURI(Uri.parse(streamUrl));
            videoView.start();
        }
    }
}
